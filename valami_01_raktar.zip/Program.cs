using Microsoft.EntityFrameworkCore;
using Scalar.AspNetCore;
using valami_01.Data;

var builder = WebApplication.CreateBuilder(args);

var cs = builder.Configuration.GetConnectionString("Default")
         ?? throw new InvalidOperationException("Hiányzik a ConnectionStrings:Default az appsettings.json-ból.");

// MariaDB 10.4 (XAMPP). Fix verzió, így induláskor nem kell csatlakozni az adatbázishoz.
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseMySql(cs, new MariaDbServerVersion(new Version(10, 4, 32))));

builder.Services.AddControllers();
builder.Services.AddOpenApi();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();   // /scalar
}

app.UseDefaultFiles();   // wwwroot/index.html
app.UseStaticFiles();
app.UseAuthorization();
app.MapControllers();

app.Run();
