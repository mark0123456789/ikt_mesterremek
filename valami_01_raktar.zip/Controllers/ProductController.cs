using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using valami_01.Data;
using valami_01.Modells;
using valami_01.Modells.DTOs;

namespace valami_01.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController(AppDbContext db) : ControllerBase
{
    private static ProductResponseDto ToDto(Product p) =>
        new(p.Id, p.Name, p.Description, p.Price, p.Stock, p.Category,
            p.Department, p.Shelf, p.SubShelf, p.ImageUrl, p.Active, p.CreatedAt);

    private static void Apply(Product p, ProductDto d)
    {
        p.Name = d.Name;
        p.Description = d.Description;
        p.Price = d.Price;
        p.Stock = d.Stock;
        p.Category = d.Category;
        p.Department = d.Department;
        // Polc nélkül nincs alpolc, osztály nélkül nincs polc
        p.Shelf = string.IsNullOrWhiteSpace(d.Department) ? null : d.Shelf;
        p.SubShelf = string.IsNullOrWhiteSpace(p.Shelf) ? null : d.SubShelf;
        p.ImageUrl = d.ImageUrl;
        p.Active = d.Active;
    }

    [HttpGet]
    public async Task<List<ProductResponseDto>> GetAll([FromQuery] string? search)
    {
        var q = db.Products.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search))
            q = q.Where(p => p.Name.Contains(search) || (p.Department != null && p.Department.Contains(search)));

        var list = await q.OrderBy(p => p.Name).ToListAsync();
        return list.Select(ToDto).ToList();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProductResponseDto>> GetById(int id)
    {
        var p = await db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return p is null ? NotFound(new { message = "A termék nem található." }) : ToDto(p);
    }

    [HttpPost]
    public async Task<ActionResult<ProductResponseDto>> Create(ProductDto dto)
    {
        var p = new Product { CreatedAt = DateTime.Now };
        Apply(p, dto);
        db.Products.Add(p);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = p.Id }, ToDto(p));
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<ProductResponseDto>> Update(int id, ProductDto dto)
    {
        var p = await db.Products.FindAsync(id);
        if (p is null) return NotFound(new { message = "A termék nem található." });
        Apply(p, dto);
        await db.SaveChangesAsync();
        return ToDto(p);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var p = await db.Products.FindAsync(id);
        if (p is null) return NotFound(new { message = "A termék nem található." });

        // ON DELETE CASCADE miatt a termékkel a rendelései is törlődnének.
        if (await db.Orders.AnyAsync(o => o.ProductId == id))
            return Conflict(new { message = "A termék szerepel rendelésben, ezért nem törölhető. Állítsd inaktívra." });

        db.Products.Remove(p);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
