using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using valami_01.Data;
using valami_01.Modells;
using valami_01.Modells.DTOs;

namespace valami_01.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UserController(AppDbContext db) : ControllerBase
{
    private static UserResponseDto ToDto(AppUser u) =>
        new(u.Id, u.Name, u.Email, u.Phone, u.Role, Roles.IsStaff(u.Role), u.RegistrationDate);

    /// <param name="type">staff = dolgozók, customer = vásárlók, üres = mindenki</param>
    [HttpGet]
    public async Task<List<UserResponseDto>> GetAll([FromQuery] string? type)
    {
        var q = db.Users.AsNoTracking();
        if (type == "staff") q = q.Where(u => Roles.Staff.Contains(u.Role));
        else if (type == "customer") q = q.Where(u => !Roles.Staff.Contains(u.Role));

        var list = await q.OrderBy(u => u.Name).ToListAsync();
        return list.Select(ToDto).ToList();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<UserResponseDto>> GetById(int id)
    {
        var u = await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return u is null ? NotFound(new { message = "A felhasználó nem található." }) : ToDto(u);
    }

    [HttpPost]
    public async Task<ActionResult<UserResponseDto>> Create(UserCreateDto dto)
    {
        if (!Roles.All.Contains(dto.Role))
            return BadRequest(new { message = "Ismeretlen jogosultság." });
        if (await db.Users.AnyAsync(u => u.Email == dto.Email))
            return Conflict(new { message = "Ez az e-mail cím már foglalt." });

        var u = new AppUser
        {
            Name = dto.Name,
            Email = dto.Email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            Phone = dto.Phone,
            Role = dto.Role,
            RegistrationDate = DateTime.Now
        };
        db.Users.Add(u);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = u.Id }, ToDto(u));
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<UserResponseDto>> Update(int id, UserUpdateDto dto)
    {
        var u = await db.Users.FindAsync(id);
        if (u is null) return NotFound(new { message = "A felhasználó nem található." });
        if (!Roles.All.Contains(dto.Role))
            return BadRequest(new { message = "Ismeretlen jogosultság." });
        if (await db.Users.AnyAsync(x => x.Email == dto.Email && x.Id != id))
            return Conflict(new { message = "Ez az e-mail cím már foglalt." });

        u.Name = dto.Name;
        u.Email = dto.Email;
        u.Phone = dto.Phone;
        u.Role = dto.Role;
        if (!string.IsNullOrEmpty(dto.Password))
            u.PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password);

        await db.SaveChangesAsync();
        return ToDto(u);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var u = await db.Users.FindAsync(id);
        if (u is null) return NotFound(new { message = "A felhasználó nem található." });

        // Az adatbázisban a rendelések ON DELETE CASCADE-del kötődnek a felhasználóhoz,
        // ezért rendelés mellett nem töröljük, nehogy eltűnjön a rendelési előzmény.
        if (await db.Orders.AnyAsync(o => o.UserId == id))
            return Conflict(new { message = "A felhasználónak vannak rendelései, ezért nem törölhető." });

        db.Users.Remove(u);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
