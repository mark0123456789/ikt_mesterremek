using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using valami_01.Data;
using valami_01.Modells;
using valami_01.Modells.DTOs;

namespace valami_01.Controllers;

/// Feladat = egy rendelés útja: Új -> Szedés alatt -> Szedve -> Csomagolás alatt -> Kész
[ApiController]
[Route("api/[controller]")]
public class WorkTaskController(AppDbContext db) : ControllerBase
{
    private static IQueryable<WorkTaskResponseDto> Project(IQueryable<WorkTask> q) =>
        q.Select(t => new WorkTaskResponseDto(
            t.Id, t.OrderId,
            t.Order!.Product!.Name, t.Order!.Quantity ?? 0,
            t.Order!.Product!.Department, t.Order!.Product!.Shelf, t.Order!.Product!.SubShelf,
            t.Status, t.PickerId, t.Picker!.Name, t.PackerId, t.Packer!.Name, t.CreatedAt));

    private static readonly string[] PickRoles = [Roles.Picker, Roles.Admin];
    private static readonly string[] PackRoles = [Roles.Packer, Roles.Admin];

    [HttpGet]
    public async Task<List<WorkTaskResponseDto>> GetAll([FromQuery] string? status)
    {
        var q = db.WorkTasks.AsNoTracking();
        if (!string.IsNullOrEmpty(status)) q = q.Where(t => t.Status == status);
        return await Project(q.OrderBy(t => t.Status == WorkStatus.Done).ThenBy(t => t.Id)).ToListAsync();
    }

    /// Hátralévő (még nem kész) rendelések száma
    [HttpGet("remaining")]
    public async Task<IActionResult> Remaining() =>
        Ok(new { remaining = await db.WorkTasks.CountAsync(t => t.Status != WorkStatus.Done) });

    [HttpPost]
    public async Task<IActionResult> Create(WorkTaskCreateDto dto)
    {
        if (!await db.Orders.AnyAsync(o => o.Id == dto.OrderId))
            return NotFound(new { message = "Nincs ilyen rendelés." });
        if (await db.WorkTasks.AnyAsync(t => t.OrderId == dto.OrderId))
            return Conflict(new { message = "Ehhez a rendeléshez már van feladat." });

        var t = new WorkTask { OrderId = dto.OrderId };
        db.WorkTasks.Add(t);
        await db.SaveChangesAsync();
        return Ok(new { id = t.Id });
    }

    /// Minden még nem csomagolt rendeléshez létrehozza a hiányzó feladatot
    [HttpPost("sync")]
    public async Task<IActionResult> Sync()
    {
        var ids = await db.Orders
            .Where(o => (o.Status == null || o.Status != "Csomagolva") && !db.WorkTasks.Any(t => t.OrderId == o.Id))
            .Select(o => o.Id)
            .ToListAsync();

        db.WorkTasks.AddRange(ids.Select(id => new WorkTask { OrderId = id }));
        await db.SaveChangesAsync();
        return Ok(new { created = ids.Count });
    }

    [HttpPost("{id}/start-pick")]
    public Task<IActionResult> StartPick(int id, WorkerDto dto) =>
        Start(id, dto.UserId, WorkStatus.Pending, WorkStatus.Picking, WorkAction.Pick, PickRoles);

    [HttpPost("{id}/finish-pick")]
    public async Task<IActionResult> FinishPick(int id)
    {
        var t = await db.WorkTasks.Include(x => x.Order).ThenInclude(o => o!.Product)
            .FirstOrDefaultAsync(x => x.Id == id);
        if (t is null) return NotFound(new { message = "A feladat nem található." });
        if (t.Status != WorkStatus.Picking) return WrongState(t);

        var product = t.Order?.Product;
        var qty = t.Order?.Quantity ?? 0;
        if (product is null) return BadRequest(new { message = "A rendeléshez nem tartozik termék." });
        if (product.Stock < qty)
            return Conflict(new { message = $"Nincs elég készlet ({product.Stock} db van, {qty} kell)." });

        product.Stock -= qty;               // a szedéssel csökken a készlet
        t.Status = WorkStatus.Picked;
        await CloseEntry(id, WorkAction.Pick);
        await db.SaveChangesAsync();
        return Ok(new { message = "Rendben." });
    }

    [HttpPost("{id}/start-pack")]
    public Task<IActionResult> StartPack(int id, WorkerDto dto) =>
        Start(id, dto.UserId, WorkStatus.Picked, WorkStatus.Packing, WorkAction.Pack, PackRoles);

    [HttpPost("{id}/finish-pack")]
    public async Task<IActionResult> FinishPack(int id)
    {
        var t = await db.WorkTasks.Include(x => x.Order).FirstOrDefaultAsync(x => x.Id == id);
        if (t is null) return NotFound(new { message = "A feladat nem található." });
        if (t.Status != WorkStatus.Packing) return WrongState(t);

        t.Status = WorkStatus.Done;
        if (t.Order is not null) t.Order.Status = "Csomagolva";
        await CloseEntry(id, WorkAction.Pack);
        await db.SaveChangesAsync();
        return Ok(new { message = "Rendben." });
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var t = await db.WorkTasks.FindAsync(id);
        if (t is null) return NotFound(new { message = "A feladat nem található." });
        if (t.Status != WorkStatus.Pending)
            return Conflict(new { message = "Csak új (még el nem kezdett) feladat törölhető." });

        db.WorkTasks.Remove(t);
        await db.SaveChangesAsync();
        return NoContent();
    }

    // ---- segédek ----
    private async Task<IActionResult> Start(int id, int userId, string required, string next, string action, string[] roles)
    {
        var t = await db.WorkTasks.FindAsync(id);
        if (t is null) return NotFound(new { message = "A feladat nem található." });
        if (t.Status != required) return WrongState(t);

        var u = await db.Users.FindAsync(userId);
        if (u is null) return NotFound(new { message = "A dolgozó nem található." });
        if (!roles.Contains(u.Role)) return BadRequest(new { message = "Ehhez a lépéshez nincs jogosultsága." });

        if (action == WorkAction.Pick) t.PickerId = userId; else t.PackerId = userId;
        t.Status = next;
        db.BacklogEntries.Add(new BacklogEntry { WorkTask = t, UserId = userId, Action = action, StartedAt = DateTime.Now });
        await db.SaveChangesAsync();
        return Ok(new { message = "Rendben." });
    }

    private async Task CloseEntry(int taskId, string action)
    {
        var e = await db.BacklogEntries
            .Where(b => b.WorkTaskId == taskId && b.Action == action && b.FinishedAt == null)
            .OrderByDescending(b => b.Id)
            .FirstOrDefaultAsync();
        if (e is not null) e.FinishedAt = DateTime.Now;
    }

    private ObjectResult WrongState(WorkTask t) =>
        Conflict(new { message = $"A feladat állapota „{t.Status}”, ezt a lépést most nem lehet elvégezni." });
}
