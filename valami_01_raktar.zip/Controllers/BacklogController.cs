using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using valami_01.Data;
using valami_01.Modells.DTOs;

namespace valami_01.Controllers;

/// Napló: ki mit szedett / csomagolt, mikor kezdte és mikor fejezte be. Csak olvasható.
[ApiController]
[Route("api/[controller]")]
public class BacklogController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<List<BacklogResponseDto>> GetAll([FromQuery] int? userId, [FromQuery] string? action)
    {
        var q = db.BacklogEntries.AsNoTracking();
        if (userId is not null) q = q.Where(b => b.UserId == userId);
        if (!string.IsNullOrEmpty(action)) q = q.Where(b => b.Action == action);

        return await q.OrderByDescending(b => b.StartedAt)
            .Select(b => new BacklogResponseDto(
                b.Id, b.WorkTaskId, b.WorkTask!.OrderId, b.UserId, b.User!.Name, b.Action,
                b.WorkTask!.Order!.Product!.Name, b.StartedAt, b.FinishedAt))
            .ToListAsync();
    }

    /// Dolgozónként és műveletenként: darabszám + átlagos idő
    [HttpGet("summary")]
    public async Task<IActionResult> Summary()
    {
        var done = await db.BacklogEntries.AsNoTracking()
            .Where(b => b.FinishedAt != null)
            .Select(b => new { b.UserId, Name = b.User!.Name, b.Action, b.StartedAt, Finished = b.FinishedAt!.Value })
            .ToListAsync();

        var result = done
            .GroupBy(x => new { x.UserId, x.Name, x.Action })
            .Select(g => new
            {
                userId = g.Key.UserId,
                name = g.Key.Name,
                action = g.Key.Action,
                count = g.Count(),
                avgSeconds = Math.Round(g.Average(x => (x.Finished - x.StartedAt).TotalSeconds))
            })
            .OrderBy(x => x.name).ThenBy(x => x.action);

        return Ok(result);
    }
}
