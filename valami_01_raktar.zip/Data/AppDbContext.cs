using Microsoft.EntityFrameworkCore;
using valami_01.Modells;

namespace valami_01.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<WorkTask> WorkTasks => Set<WorkTask>();
    public DbSet<BacklogEntry> BacklogEntries => Set<BacklogEntry>();
}
