using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace valami_01.Modells;

[Table("products")]
public class Product
{
    [Column("id")] public int Id { get; set; }
    [Column("name"), MaxLength(100)] public string Name { get; set; } = "";
    [Column("description")] public string? Description { get; set; }
    [Column("price")] public decimal Price { get; set; }
    [Column("stock")] public int Stock { get; set; }
    [Column("category"), MaxLength(50)] public string? Category { get; set; }
    // Raktári hely (új oszlopok, lásd adatbazis_bovites.sql)
    [Column("department"), MaxLength(50)] public string? Department { get; set; }
    [Column("shelf"), MaxLength(20)] public string? Shelf { get; set; }
    [Column("sub_shelf"), MaxLength(20)] public string? SubShelf { get; set; }
    [Column("image_url")] public string? ImageUrl { get; set; }
    [Column("active")] public bool Active { get; set; } = true;
    [Column("created_at")] public DateTime CreatedAt { get; set; } = DateTime.Now;
}
