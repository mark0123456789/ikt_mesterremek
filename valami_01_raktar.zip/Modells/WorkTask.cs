using System.ComponentModel.DataAnnotations.Schema;

namespace valami_01.Modells;

[Table("work_tasks")]
public class WorkTask
{
    [Column("id")] public int Id { get; set; }
    [Column("order_id")] public int OrderId { get; set; }
    [Column("picker_id")] public int? PickerId { get; set; }
    [Column("packer_id")] public int? PackerId { get; set; }
    [Column("status")] public string Status { get; set; } = WorkStatus.Pending;
    [Column("created_at")] public DateTime CreatedAt { get; set; } = DateTime.Now;

    public Order? Order { get; set; }
    [ForeignKey(nameof(PickerId))] public AppUser? Picker { get; set; }
    [ForeignKey(nameof(PackerId))] public AppUser? Packer { get; set; }
}

public static class WorkStatus
{
    public const string Pending = "Új";
    public const string Picking = "Szedés alatt";
    public const string Picked = "Szedve";
    public const string Packing = "Csomagolás alatt";
    public const string Done = "Kész";
}
