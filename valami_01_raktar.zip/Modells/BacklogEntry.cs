using System.ComponentModel.DataAnnotations.Schema;

namespace valami_01.Modells;

[Table("backlog_entries")]
public class BacklogEntry
{
    [Column("id")] public int Id { get; set; }
    [Column("work_task_id")] public int WorkTaskId { get; set; }
    [Column("user_id")] public int? UserId { get; set; }
    [Column("action")] public string Action { get; set; } = "";
    [Column("started_at")] public DateTime StartedAt { get; set; } = DateTime.Now;
    [Column("finished_at")] public DateTime? FinishedAt { get; set; }

    public WorkTask? WorkTask { get; set; }
    public AppUser? User { get; set; }
}

public static class WorkAction
{
    public const string Pick = "Szedés";
    public const string Pack = "Csomagolás";
}
