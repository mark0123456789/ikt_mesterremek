using System.ComponentModel.DataAnnotations.Schema;

namespace valami_01.Modells;

// A webshop rendelései (meglévő tábla). A raktár csak olvassa, és az állapotát frissíti.
[Table("orders")]
public class Order
{
    [Column("id")] public int Id { get; set; }
    [Column("user_id")] public int? UserId { get; set; }
    [Column("product_id")] public int? ProductId { get; set; }
    [Column("quantity")] public int? Quantity { get; set; }
    [Column("unit_price")] public decimal? UnitPrice { get; set; }
    [Column("order_date")] public DateTime? OrderDate { get; set; }
    [Column("status")] public string? Status { get; set; }
    [Column("payment_method")] public string? PaymentMethod { get; set; }
    [Column("shipping_method")] public string? ShippingMethod { get; set; }
    [Column("total_price")] public decimal? TotalPrice { get; set; }

    public Product? Product { get; set; }
}
