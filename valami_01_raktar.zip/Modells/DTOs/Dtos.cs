using System.ComponentModel.DataAnnotations;

namespace valami_01.Modells.DTOs;

// ---- Felhasználók ----
public record UserCreateDto(
    [Required, StringLength(100)] string Name,
    [Required, EmailAddress, StringLength(100)] string Email,
    [Required, MinLength(6)] string Password,
    [StringLength(20)] string? Phone,
    [Required] string Role);

public record UserUpdateDto(
    [Required, StringLength(100)] string Name,
    [Required, EmailAddress, StringLength(100)] string Email,
    [MinLength(6)] string? Password,          // null = nem változik
    [StringLength(20)] string? Phone,
    [Required] string Role);

public record UserResponseDto(int Id, string Name, string Email, string? Phone,
    string Role, bool IsStaff, DateTime RegistrationDate);

// ---- Termékek ----
public record ProductDto(
    [Required, StringLength(100)] string Name,
    string? Description,
    [Range(0, 100000000)] decimal Price,
    [Range(0, int.MaxValue)] int Stock,
    [StringLength(50)] string? Category,
    [StringLength(50)] string? Department,
    [StringLength(20)] string? Shelf,
    [StringLength(20)] string? SubShelf,
    string? ImageUrl,
    bool Active);

public record ProductResponseDto(int Id, string Name, string? Description, decimal Price, int Stock,
    string? Category, string? Department, string? Shelf, string? SubShelf,
    string? ImageUrl, bool Active, DateTime CreatedAt);

// ---- Feladatok ----
public record WorkTaskCreateDto([Range(1, int.MaxValue)] int OrderId);

public record WorkerDto([Range(1, int.MaxValue)] int UserId);

public record WorkTaskResponseDto(int Id, int OrderId, string? ProductName, int Quantity,
    string? Department, string? Shelf, string? SubShelf, string Status,
    int? PickerId, string? PickerName, int? PackerId, string? PackerName, DateTime CreatedAt);

// ---- Backlog ----
public record BacklogResponseDto(int Id, int WorkTaskId, int OrderId, int? UserId, string? UserName,
    string Action, string? ProductName, DateTime StartedAt, DateTime? FinishedAt)
{
    public double? DurationSeconds => FinishedAt is null ? null : (FinishedAt.Value - StartedAt).TotalSeconds;
}
