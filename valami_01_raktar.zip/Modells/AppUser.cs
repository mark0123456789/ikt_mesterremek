using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace valami_01.Modells;

[Table("users")]
public class AppUser
{
    [Column("id")] public int Id { get; set; }
    [Column("name"), MaxLength(100)] public string Name { get; set; } = "";
    [Column("email"), MaxLength(100)] public string Email { get; set; } = "";
    [Column("password_hash")] public string PasswordHash { get; set; } = "";
    [Column("phone"), MaxLength(20)] public string? Phone { get; set; }
    [Column("role"), MaxLength(20)] public string Role { get; set; } = Roles.Customer;
    [Column("registration_date")] public DateTime RegistrationDate { get; set; } = DateTime.Now;
}

public static class Roles
{
    public const string Admin = "admin";
    public const string Picker = "picker";
    public const string Packer = "packer";
    public const string Customer = "customer";

    public static readonly string[] Staff = [Admin, Picker, Packer];
    public static readonly string[] All = [Admin, Picker, Packer, Customer];

    public static bool IsStaff(string role) => Staff.Contains(role);
}
