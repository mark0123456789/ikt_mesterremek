-- furniq adatbázis bővítése a raktárkezelőhöz (phpMyAdmin > furniq > SQL fül)
USE `furniq`;

-- 1) Raktári hely a termékekhez
ALTER TABLE `products`
  ADD COLUMN `department` varchar(50) DEFAULT NULL AFTER `category`,
  ADD COLUMN `shelf` varchar(20) DEFAULT NULL AFTER `department`,
  ADD COLUMN `sub_shelf` varchar(20) DEFAULT NULL AFTER `shelf`;

-- 2) Feladatok: rendelés -> szedő -> csomagoló
CREATE TABLE `work_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `picker_id` int(11) DEFAULT NULL,
  `packer_id` int(11) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Új',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_tasks_order` (`order_id`),
  KEY `fk_work_tasks_picker` (`picker_id`),
  KEY `fk_work_tasks_packer` (`packer_id`),
  CONSTRAINT `fk_work_tasks_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_work_tasks_picker` FOREIGN KEY (`picker_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_work_tasks_packer` FOREIGN KEY (`packer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 3) Backlog: ki mit csinált, mikor kezdte és fejezte be
CREATE TABLE `backlog_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `work_task_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `started_at` datetime NOT NULL,
  `finished_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_backlog_task` (`work_task_id`),
  KEY `fk_backlog_user` (`user_id`),
  CONSTRAINT `fk_backlog_task` FOREIGN KEY (`work_task_id`) REFERENCES `work_tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_backlog_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 4) TESZTADAT (opcionális). Előbb hozz létre legalább egy "customer" jogosultságú
--    felhasználót a felületen, utána futtasd ezt a részt.
INSERT INTO `products` (`name`,`description`,`price`,`stock`,`category`,`department`,`shelf`,`sub_shelf`,`active`,`created_at`) VALUES
('Oslo háromszemélyes kanapé','Szürke szövetkárpit',189900,4,'Kanapé','Ülőbútor','A3','2',1,NOW()),
('Nordic étkezőasztal','Tölgy, 160 cm',129900,6,'Asztal','Asztalok','B1','1',1,NOW()),
('Lund könyvespolc','Fehér, 5 polcos',49900,10,'Polc','Tárolás','C2','4',1,NOW());

INSERT INTO `orders` (`user_id`,`product_id`,`quantity`,`unit_price`,`order_date`,`status`,`payment_method`,`shipping_method`,`total_price`)
SELECT u.id, p.id, 1, p.price, NOW(), 'Feldolgozás alatt', 'Utánvét', 'Futár', p.price
FROM `users` u CROSS JOIN `products` p
WHERE u.role = 'customer' AND p.name IN ('Oslo háromszemélyes kanapé','Lund könyvespolc')
LIMIT 2;
